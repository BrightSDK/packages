// LICENCE_CODE ZON
'use strict'; /*jslint node:true es9:true*/
const child_process = require("child_process");
const fs = require("fs");
const path = require("path");
const chalk = require("chalk");
const shell_escape = require("shell-escape");
const { log_factory: Log_factory } = require("brd-ono-util-logger");

let init_exec;
let debug;

const colors = [
    "blue", "green", "yellow", "cyan", "magenta",
    "bgGreen", "bgYellow", "bgBlue", "bgCyan", "bgMagenta", "bgWhite"
];
const color = (s, c)=>chalk[c](s);

const exec = (cmd, args = [], opt = {})=>{
    const { idx=0, label, quiet, verbose, save, save_err, options } = opt;
    if (debug)
    {
        debug.main("running cmd: %s %s", cmd, shell_escape(args));
        debug.exec("%s %s #%s", cmd, shell_escape(args), label || "root");
    }
    return new Promise((resolve, reject)=>{
        const child = child_process.spawn(cmd, args, options);
        const c_idx = idx % colors.length;
        const c = colors[c_idx];
        const prefix = label ? color(`[${label}] `, c) : "";
        const fmt = (s)=>prefix + s;
        let result = '';

        if (!quiet)
        {
            child.stdout.on("data", (s)=>{
                if (verbose)
                {
                    process.stdout.write(fmt(s));
                }
                if (save)
                {
                    result += s;
                }
            });
            child.stderr.on("data", (s)=>{
                if (save_err)
                {
                    result += s;
                }
                else
                {
                    process.stderr.write(fmt(s));
                }
            });
        }

        child.on("close", (code)=>{
            if (code)
            {
                return reject(new Error(`${cmd} failed: ps process exited with code ${code}`));
            }
            resolve(result);
        });
    });
};

const docker_exec = async (docker_image, volume, args = [], exec_opt = {}, docker_opt = {})=>{
    const {
        ipc_lock, docker_entrypoint, docker_volume="/data", docker_cwd,
        autoremove=true, mounts=[], env={}, memory, memory_swap,
    } = docker_opt;
    const base_args = ["run"];
    if (memory)
        base_args.push(`--memory=${memory}`);
    if (memory_swap)
        base_args.push(`--memory-swap=${memory_swap}`);
    if (docker_entrypoint)
        base_args.push(`--entrypoint=${docker_entrypoint}`);
    if (volume)
    {
        mounts.push({src: volume, dst: docker_volume});
        base_args.push("-w", docker_cwd || docker_volume);
    }
    for (const {src, dst} of mounts)
        base_args.push("-v", `${src}:${dst}`);
    for (const key in env)
        base_args.push("-e", `${key}=${env[key]}`);
    if (autoremove)
        base_args.push("--rm");
    if (ipc_lock)
        base_args.push("--cap-add", "ipc_lock");
    return await exec("docker", [
        ...base_args,
        "--network", "host",
        docker_image,
        ...args
    ], exec_opt);
};

const default_filename_fn = (pid)=>`ps_${pid}_exec.log`;
const default_filename = path.join(".", default_filename_fn(process.pid));
const default_filename_mask = default_filename_fn("*");

const Exec = function(opt = {}) {
    let {
        filename=default_filename, filename_mask, log_factory=new Log_factory(),
        log_level="debug", log_format_fn=({message})=>message, reinit=false,
    } = opt;

    if (!filename_mask)
    {
        if (filename == default_filename)
            filename_mask = default_filename_mask;
        else
            filename_mask = filename;
    }

    if (!init_exec || reinit)
    {
        init_exec = new Promise((resolve, reject)=>{
            debug = {
                main: log_factory.create_debug_logger("main"),
                exec: log_factory.create_debug_logger("exec"),
            };
            exec("rm", ["-f", filename_mask], {options: {shell: true}})
                .then(()=>{
                    debug.main("log cleanup complete");
                    const env = Object.entries(process.env).reduce(
                        (r, [k, v])=>r.concat(`${k}=${v}`), []
                    );
                    fs.writeFileSync(
                        filename,
                        `${env.join("\n")}\n${process.argv.join(" ")}\n\n`
                    );
                    log_factory.add_file_logger("exec", {
                        level: log_level,
                        format_fn: log_format_fn,
                        filename
                    });
                })
                .then(resolve)
                .catch(reject);
        });
    }

    return {
        exec: (...args)=>init_exec.then(()=>exec(...args)),
        docker_exec: (...args)=>init_exec.then(()=>docker_exec(...args)),
        cleanup: ()=>fs.unlinkSync(filename),
    };
};

module.exports = {Exec};
