const { Exec } = require("../index.js");

const { exec, dockerExec, cleanup } = Exec({
  filename: "examples/helloworld.log",
});

(async () => {
  await exec("echo", ["Hello World"]);
  await dockerExec("hello-world");
  cleanup();
})();
