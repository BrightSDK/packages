// LICENCE_CODE ZON
'use strict'; /*jslint node:true es9:true*/
const {expect} = require("chai");
const sinon = require("sinon");
const fs = require("fs");
const child_process = require("child_process");
const {log_factory: LogFactory} = require("brd-ono-util-logger");
const {Exec} = require("../index.js");

describe("exec function tests", function(){
    let sandbox;
    let exec;
    let exec_cleanup;
    let cleanup;
    const custom_log_filename = "test/custom.log";
    const cmd = "echo";
    const arg = "Hello World";

    before(()=>{
        sandbox = sinon.createSandbox();
        sandbox.stub(fs, "writeFileSync");
        ({exec, cleanup: exec_cleanup} = Exec({reinit: true}));
    });

    after(()=>{
        sandbox.restore();
        exec_cleanup();
    });

    it("should initialize with default parameters", async ()=>{
        expect(exec).to.be.a("function");
    });

    it("should handle custom parameters", async ()=>{
        const custom_log_factory = new LogFactory();
        expect(fs.existsSync(custom_log_filename)).to.be.false;
        ({exec} = Exec({
            reinit: true,
            filename: custom_log_filename,
            logFactory: custom_log_factory,
            logLevel: "info",
        }));
        expect(exec).to.be.a("function");
        await exec(cmd, [arg]);
        expect(fs.existsSync(custom_log_filename)).to.be.true;
    });

    it("should write commands to log", async ()=>{
        ({exec, cleanup} = Exec({reinit: true, filename: custom_log_filename}));
        await exec(cmd, [arg]);
        const log = fs.readFileSync(custom_log_filename, "utf8");
        expect(log).to.equal(`${cmd} '${arg}' #root\n`);
        cleanup();
    });

    it("should execute a command successfully", async ()=>{
        const result = await exec(cmd, [arg], {save: true});
        expect(result).to.equal(`${arg}\n`);
    });

    it("should handle command execution failure", async ()=>{
        sandbox.stub(child_process, "spawn").callsFake(()=>({
            on: (event, callback) =>
            {
                if (event === "close")
                    callback(1);
            },
            stdout: {on: ()=>{}},
            stderr: {on: ()=>{}},
        }));
        try {
            await exec("false");
        } catch (error) {
            expect(error).to.be.an("error");
        }
    });
});

describe("docker_exec function tests", function(){
    let sandbox;
    let docker_exec;
    let docker_exec_cleanup;
    const docker_image = "hello-world";
    const custom_docker_log_filename = "test/docker_custom.log";

    this.timeout(30000);

    before(()=>{
        sandbox = sinon.createSandbox();
        sandbox.stub(fs, "writeFileSync");
        ({docker_exec, cleanup: docker_exec_cleanup} = Exec({
            reinit: true,
            filename: custom_docker_log_filename,
            logFactory: new LogFactory(),
            logLevel: "debug",
            docker: true,
        }));
    });

    after(()=>{
        sandbox.restore();
        docker_exec_cleanup();
    });

    it("should handle Docker command execution", async ()=>{
        await docker_exec(docker_image, null, [], {save: true});
        const log = fs.readFileSync(custom_docker_log_filename, "utf8");
        expect(log).to.include("docker run");
        expect(log).to.include(docker_image);
    });

    it("should execute a Docker command successfully", async ()=>{
        const result = await docker_exec(docker_image, null, [], {save: true});
        expect(result).to.include("Hello from Docker!");
    });

    it("should pass mounts to Docker command", async ()=>{
        const volume = "/tmp/data";
        const mounts = [
            {src: "/tmp/foo", dst: "/foo"},
            {src: "/tmp/bar", dst: "/bar"},
        ];
        await docker_exec(docker_image, volume, [], {save: true}, {mounts});
        const log = fs.readFileSync(custom_docker_log_filename, "utf8");
        for (const {src, dst} of mounts.concat({src: volume, dst: "/data"}))
        {
            expect(log).to.include(`-v '${src}:${dst}'`);
        }
    });

    it("should handle Docker command execution failure", async ()=>{
        sandbox.stub(child_process, "spawn").callsFake(()=>({
            on: (event, callback) =>
            {
                if (event === "close")
                    callback(1); // Simulate a failure
            },
            stdout: {on: ()=>{}},
            stderr: {on: ()=>{}},
        }));
        try {
            await docker_exec("nonexistentimage", null, [], {save: true});
        } catch (error) {
            expect(error).to.be.an("error");
            expect(error.message).to.include("docker failed: ps process exited");
        }
    });
});
