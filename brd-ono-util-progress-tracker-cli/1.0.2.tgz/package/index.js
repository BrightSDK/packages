// LICENSE_CODE ZON
'use strict';

/**
 * Export the progress tracker CLI module
 * @module brd-ono-util-progress-tracker-cli
 */
module.exports = require('./src/main');
