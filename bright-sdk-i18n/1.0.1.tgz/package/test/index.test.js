const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');
const child = require('child_process');
const { fetchAndUnzip } = require('../src/index');

function mkdtemp(prefix) {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

async function main() {
  const tmp = mkdtemp('i18n-test-');
  const srcDir = path.join(tmp, 'src');
  // use consumer default output folder name './locales' inside our temp dir
  const outDir = path.join(tmp, 'locales');
  fs.mkdirSync(srcDir, { recursive: true });
  fs.mkdirSync(outDir, { recursive: true });

  const en = path.join(srcDir, 'en_US.json');
  const ru = path.join(srcDir, 'ru_RU.json');
  const de = path.join(srcDir, 'de_DE.json');
  fs.writeFileSync(en, JSON.stringify({ hello: 'world' }));
  fs.writeFileSync(ru, JSON.stringify({ privet: 'mir' }));
  fs.writeFileSync(de, JSON.stringify({ hallo: 'welt' }));

  const zipPath = path.join(tmp, 'locales.zip');
  try {
    // create zip using system `zip` (we assume it's available where unzip/wget are)
    child.execSync(`zip -j ${zipPath} ${en} ${ru} ${de}`);
  } catch (e) {
    console.error('Failed to create zip using system zip:', e.message);
    process.exit(2);
  }

  const url = 'file://' + zipPath;

  try {
    // options.docker mirrors the CLI --docker boolean
    const saved = await fetchAndUnzip(url, outDir, { verbose: false, docker: false, languages: 'en,ru', delete: true });
    // verify saved contains en_US.json and ru_RU.json
    const enOut = path.join(outDir, 'en_US.json');
    const ruOut = path.join(outDir, 'ru_RU.json');
    const deOut = path.join(outDir, 'de_DE.json');

    assert.ok(fs.existsSync(enOut), 'en_US.json should exist');
    assert.ok(fs.existsSync(ruOut), 'ru_RU.json should exist');
    // de should not exist because we filtered to en,ru and delete=true should remove others
    assert.ok(!fs.existsSync(deOut), 'de_DE.json should not exist');

    console.log('TEST: Passed');
    process.exit(0);
  } catch (err) {
    console.error('TEST: Failed:', err && err.stack ? err.stack : err);
    process.exit(1);
  }
}

main();
