const path = require('path');

/**
 * Download a file using wget via the provided Exec instance.
 * Supports running wget inside Docker by calling exec.docker_exec when dockerImage is present.
 * @param {object} exec - Exec instance from brd-ono-util-exec
 * @param {string} url - URL to download
 * @param {string} dest - destination path on host
 * @param {object} options - { docker, label, verbose, wgetArgs }
 */
async function downloadWithWget(exec, url, dest, options = {}) {
  const { docker, label, verbose, wgetArgs = [] } = options;
  const defaultDownloadImage = 'inutano/wget';

    // support file:// local paths by copying directly (avoids calling wget)
    if (String(url).startsWith('file://')) {
      const fs = require('fs');
      const src = url.replace(/^file:\/+/,'/');
      // src should now be an absolute path
      fs.copyFileSync(src, dest);
      return;
    }

  if (docker) {
    const downloadImage = defaultDownloadImage;
    const hostTmp = path.dirname(dest);
    const zipName = path.basename(dest);
    const containerZip = `/data/${zipName}`;
    const sh = `wget -q ${wgetArgs.join(' ')} -O '${containerZip}' '${url}'`;
    await exec.docker_exec(downloadImage, hostTmp, ['sh', '-c', sh], {
        label: label || 'wget-docker',
        verbose: !!verbose
    }, { mounts: [{ src: hostTmp, dst: '/data' }], docker_cwd: '/data' });
    return;
  }

  const args = ['-q', '-O', dest, url, ...wgetArgs];
  await exec.exec('wget', args, { label: label || 'wget', verbose: !!verbose });
}

module.exports = { downloadWithWget };
