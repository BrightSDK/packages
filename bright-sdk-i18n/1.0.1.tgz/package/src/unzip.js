const fs = require('fs');
const path = require('path');

/**
 * Unzip helper that runs local `unzip` or unzips inside Docker when `options.docker` is true.
 * @param {object} exec - Exec instance from brd-ono-util-exec
 * @param {string} zipPath - path to the zip file on the host
 * @param {string} outDir - destination directory on the host
 * @param {object} options - { docker, label, verbose }
 */
async function unzip(exec, zipPath, outDir, options = {}) {
  fs.mkdirSync(outDir, { recursive: true });
  if (options && options.docker) {
    // Docker path: mount outDir -> /data and zipPath's dir -> /zipdata, unzip directly into /data
    const defaultUnzipImage = 'joshkeegan/zip';
    const dockerImage = defaultUnzipImage;
    const zipDir = path.dirname(zipPath);
    const zipName = path.basename(zipPath);
    const args = ['sh', '-c', `unzip -o '/zipdata/${zipName}' -d '/data'`];
    await exec.docker_exec(dockerImage, outDir, args, { label: options.label || 'unzip-docker', verbose: !!options.verbose }, { mounts: [{ src: zipDir, dst: '/zipdata' }], docker_cwd: '/data' });
    return;
  }

  // Local path: run unzip on host
  const args = ['-o', zipPath, '-d', outDir];
  await exec.exec('unzip', args, { label: options.label || 'unzip', verbose: !!options.verbose });
}

module.exports = { unzip };
