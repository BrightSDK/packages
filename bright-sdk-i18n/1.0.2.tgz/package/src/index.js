#!/usr/bin/env node
/*
 * src/index.js - CLI + Node API to fetch a ZIP of locale JSON files and extract them.
 * Uses local brd-ono-util-exec to run system unzip (or unzip inside Docker).
 */
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Exec } = require('brd-ono-util-exec');
const { downloadWithWget } = require('./download');
const { unzip } = require('./unzip');
const { log_factory: Log_factory } = require('brd-ono-util-logger');

// create a simple console logger via log_factory
const logFactory = new Log_factory();
const info = logFactory.create_logger('info');
const debug = logFactory.create_debug_logger('i18n');

async function fetchAndUnzip(url, outDir, options = {}) {
	if (!url) throw new Error('url is required');
	if (!outDir) throw new Error('outDir is required');

	fs.mkdirSync(outDir, { recursive: true });

		const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'bright-i18n-'));
		const zipPath = path.join(tmpDir, 'locales.zip');

		const exec = new Exec({ filename: options.logFile || path.join(tmpDir, 'fetch-locales.log'), log_level: options.verbose ? 'debug' : 'info' });

	info('Starting fetchAndUnzip: url=%s outDir=%s docker=%s', url, outDir, !!options.docker);
		debug('tmpDir=%s zipPath=%s', tmpDir, zipPath);

		// download using wget (local or docker)
		info('Downloading %s -> %s', url, zipPath);
		await downloadWithWget(exec, url, zipPath, options);
		info('Download complete: %s', zipPath);

		try {
			// unzip (local or docker) using same options
			// extract into a temporary extraction directory inside tmpDir to avoid partial writes to outDir
			const extractDir = path.join(tmpDir, 'bright-sdk-i18n-extract-'+Date.now());
			fs.mkdirSync(extractDir, { recursive: true });
			info('Unzipping %s -> %s (temp)', zipPath, extractDir);
			await unzip(exec, zipPath, extractDir, options);
			info('Unzip complete (temp)');

				// scan extractDir recursively for .json files
				const savedAll = [];
				const walk = (dir)=>{
					for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
						const p = path.join(dir, entry.name);
						if (entry.isDirectory()) walk(p);
						else if (entry.isFile() && entry.name.endsWith('.json')) savedAll.push(p);
					}
				};
				walk(extractDir);

			// ensure output dir exists
			fs.mkdirSync(outDir, { recursive: true });

			// copy allowed files from extractDir to outDir (preserve relative paths)
			let saved = [];
			// normalize allowed languages: accept array or comma-separated string, lowercase
			let allowed = null;
			if (options.languages) {
				let arr = Array.isArray(options.languages) ? options.languages : String(options.languages).split(',');
				arr = arr.map(s => String(s).trim().toLowerCase()).filter(Boolean);
				if (arr.length) allowed = new Set(arr);
			}

			const matchesAllowed = (fileLang)=>{
				if (!allowed) return true;
				const fl = String(fileLang).toLowerCase();
				const primary = fl.split(/[_-]/)[0];
				return allowed.has(fl) || allowed.has(primary);
			};

			for (const srcPath of savedAll) {
				const fileLang = path.basename(srcPath, '.json');
				const rel = path.relative(extractDir, srcPath);
				const destPath = path.join(outDir, rel);
				fs.mkdirSync(path.dirname(destPath), { recursive: true });
				if (matchesAllowed(fileLang)) {
					fs.copyFileSync(srcPath, destPath);
					debug('Created %s', destPath);
					saved.push(destPath);
				} else {
					debug('Skipped %s', srcPath);
				}
			}

			// if delete flag is set, remove any files in outDir that are not in the allowed set
			if (options.delete && allowed) {
				const outJsons = [];
				const walkOut = (dir)=>{
					for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
						const p = path.join(dir, entry.name);
						if (entry.isDirectory()) walkOut(p);
						else if (entry.isFile() && entry.name.endsWith('.json')) outJsons.push(p);
					}
				};
				walkOut(outDir);
				for (const p of outJsons) {
					const lang = path.basename(p, '.json');
					if (!matchesAllowed(lang)) {
						try { fs.unlinkSync(p); debug('Removed existing non-requested file from outDir: %s', p); } catch (e) { debug('Failed to remove %s: %s', p, e.message); }
					}
				}
			}

			if (saved.length === 0) {
				info('No locale JSON files were saved in %s', outDir);
			} else {
				info('Saved %d locale file(s):', saved.length);
				for (const f of saved) info('  - %s', f);
			}
			return saved;
        } finally {
            try { exec.cleanup(); } catch (e) {}
            // do not remove tmpDir so user can inspect if needed
        }
}

module.exports = { fetchAndUnzip };
