#!/usr/bin/env node
/*
 * Root CLI for bright-sdk-i18n. Parses arguments with yargs and delegates
 * the work to `src/index.js` which exposes `fetchAndUnzip`.
 */
'use strict';
const path = require('path');
const yargs = require('yargs');
const { hideBin } = require('yargs/helpers');
const { fetchAndUnzip } = require('./src/index');

(async function main() {
  const argv = yargs(hideBin(process.argv))
    .usage('Usage: $0 <zip-url> <out-dir> OR $0 <out-dir> [options]')
    .option('docker', { type: 'boolean', describe: 'Run download/unzip inside Docker (uses default images)' })
    .option('base-url', { type: 'string', describe: 'Base URL to build zip from when zip-url is omitted', default: 'https://sdk-video.brightdata.com/i18n' })
    .option('project-name', { type: 'string', describe: 'Project name to build zip from when zip-url is omitted', default: 'consent-screen' })
    .option('verbose', { type: 'boolean', describe: 'Verbose logging' })
    .option('delete', { type: 'boolean', describe: 'Delete non-requested language files after extraction' })
    .option('languages', { type: 'string', describe: 'Comma-separated list of language codes to keep (e.g. en,fr,de)' })
    .option('log', { type: 'string', describe: 'Path to log file' })
    .demandCommand(1)
    .help()
    .argv;

  // positional args: either (zipUrl, outDir) or (outDir)
  const pos = argv._;
  let zipUrl;
  let outDir;
  if (pos.length === 2) {
    zipUrl = pos[0];
    outDir = pos[1];
  } else if (pos.length === 1) {
    outDir = pos[0];
    const base = (argv['base-url'] || '').replace(/\/$/, '');
    const project = argv['project-name'] || 'sdk-consent';
    zipUrl = `${base}/${project}.zip`;
  } else {
    console.error('Missing required arguments. Provide <zip-url> <out-dir> or just <out-dir> with --base-url and --project-name.');
    process.exit(2);
  }

  const options = {
    dockerImage: !!argv.docker,
    verbose: !!argv.verbose,
    delete: !!argv.delete,
    logFile: argv.log,
    languages: argv.languages ? argv.languages.split(',').map(s=>s.trim()).filter(Boolean) : undefined,
  };

  try {
    const saved = await fetchAndUnzip(zipUrl, outDir, options);
    process.exit(0);
  } catch (err) {
    console.error('Error:', err && err.message ? err.message : err);
    process.exit(1);
  }
})();
