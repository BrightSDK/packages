// LICENSE_CODE ZON
'use strict';
const os = require('os');
const path = require('path');
const { Exec }  = require('brd-ono-util-exec');
const {parsed: env} = require('dotenv').config();
const createProgressTracker = require('brd-ono-util-progress-tracker-cli');
const pkg = require('./package.json');

const {exec, docker_exec} = new Exec();

const docker_image = env.TIZEN_DOCKER_IMAGE
    || 'brightvideo/docker-tizen-webos-sdk:1.0.0';

const run_in_docker = async(cmd, args, cwd, opt)=>{
    await docker_exec(docker_image, path.resolve(cwd),
        [cmd, ...args],
        {verbose: false},
        opt,
    );
};

const signing = {
    profile: env.TIZEN_PROFILE_NAME,
    author: {
        cert: env.TIZEN_AUTHOR_CERT_FILENAME,
        pass: env.TIZEN_AUTHOR_CERT_PASS,
    },
    distributor: {
        cert: env.TIZEN_DISTRIBUTOR_CERT_FILENAME,
        pass: env.TIZEN_DISTRIBUTOR_CERT_PASS,
    },
};

// Step configurations with timing data
const STEPS = {
    PREPARE: {
        name: 'prepare',
        endPercentage: 10,
        label: 'Preparing... (1/4)',
    },
    REBUILD: {
        name: 'rebuild',
        endPercentage: 35,
        label: 'Rebuilding... (2/4)',
    },
    PACKAGE: {
        name: 'package',
        endPercentage: 90,
        label: 'Packaging... (3/4)',
    },
    FINALIZE: {
        name: 'finalize',
        endPercentage: 100,
        label: 'Finalizing... (4/4)',
    },
};

// Initialize the progress tracker with debug mode based on environment variable
const trackProgress = createProgressTracker({
    name: pkg.name,
    debug: false,
    summary: { enabled: false },
});

// Convert resign to a generator function
async function* resignGenerator(input_filename, output_filename) {

    // Create temp directory in system temp dir
    const dir = path.join(os.tmpdir(), pkg.name);
    const ext = path.extname(input_filename)
    const input_basename = path.basename(input_filename);
    const input_name = path.basename(input_basename, ext);
    const workdir = path.join(dir, input_name);

    // Preparing phase
    yield STEPS.PREPARE;
    await exec('rm', ['-rf', workdir]);
    await exec('mkdir', ['-p', workdir]);
    await exec('cp', ['-r', input_filename, dir]);
    await run_in_docker('unzip', [input_basename, '-d', path.join('/data', input_name)], dir);

    await exec('rm', ['-f', // ignore if some files are not present
        path.join(dir, input_basename),
        path.join(workdir, 'author-signature.xml'),
        path.join(workdir, 'signature1.xml'),
    ]);

    // Rebuilding phase
    yield STEPS.REBUILD;
    await run_in_docker('tizen', ['build-web', '--', '.'], workdir);

    // Packaging phase
    yield STEPS.PACKAGE;
    const certs_alias = '/certificates';
    await run_in_docker('dbus-run-session', [
        '/scripts/package',
        '--type', 'wgt',
        '--sign', signing.profile,
        '--output', '.', '--', './.buildResult',
    ], workdir, {
        ipc_lock: true,
        env: {
            SIGN_PROFILE: signing.profile,
            SIGN_AUTHOR_CERT: path.join(certs_alias, signing.author.cert),
            SIGN_AUTHOR_CERT_PASS: signing.author.pass,
            SIGN_DISTRIBUTOR_CERT: path.join(certs_alias, signing.distributor.cert),
            SIGN_DISTRIBUTOR_CERT_PASS: signing.distributor.pass,
        },
        mounts: [{src: path.resolve(env.TIZEN_CERTS_DIR), dst: certs_alias}],
    });

    // Finalizing phase
    yield STEPS.FINALIZE;
    const data = await exec('find', [dir, '-name', '*.wgt'], {save: true});
    const [src] = data.trim().split('\n');
    await exec('mv', [src, output_filename]);
    await exec('rm', ['-rf', workdir]);

    return output_filename;
}

const sleep = ms => new Promise(resolve=>setTimeout(resolve, ms));

async function* resignGeneratorMock (input_filename, output_filename) {
    await exec('cp', [input_filename, output_filename]);
    let percentage = 0;
    for (const step of [
        STEPS.PREPARE,
        STEPS.REBUILD,
        STEPS.PACKAGE,
        STEPS.FINALIZE,
    ]) {
        const ms = (step.endPercentage - percentage) * 200; // 1% = 200ms, 100% = 20s
        percentage = step.endPercentage;
        yield step;
        await sleep(ms);
    }
    return output_filename;
}

const resign = async (input_filename, output_filename) => {
    trackProgress.start();

    // Process the generator
    const generator = resignGenerator(input_filename, output_filename);
    let result = await generator.next();

    while (!result.done) {
        trackProgress.updateStep(result.value); // Pass the step object which now represents the starting step
        result = await generator.next();
    }

    return result.value;
};

const main = async() => {
    // read wgt filename from args
    const args = process.argv.slice(2);
    if (args.length < 1) {
        console.error('Usage: node index.js <input.wgt> [output.wgt]');
        process.exit(1);
    }
    const [input, output = './output.wgt'] = args;
    await resign(input, output);
    console.log(`Resigned ${input} to ${output} using ${signing.profile}`);
    trackProgress.summary();
};

if (require.main === module)
{
    main().catch((err)=>{
        console.error(err);
        process.exit(1);
    });
}

module.exports = { resignGenerator, resignGeneratorMock };