npm install ../exec
npm install ../logger