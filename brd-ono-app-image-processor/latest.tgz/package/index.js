const fs = require('fs');
const path = require('path');
const { log_factory: LogFactory } = require('brd-ono-util-logger');
const { Exec } = require('brd-ono-util-exec');

const { exec, docker_exec } = Exec();

const resizeImage = async(src_name, dst_name, dir, opt={})=>{
    const {docker, size, scale, gravity='center', exec_opt} = opt;
    const params = [
        '-resize', (scale || size )+ '^',
        '-background', 'none',
        '-gravity', gravity,
        '-extent', size,
    ];
    if (docker)
    {
        const docker_volume = '/imgs';
        await docker_exec('dpokidov/imagemagick:7.1.1-20', dir, [
            `${docker_volume}/${src_name}`,
            ...params,
            `${docker_volume}/${dst_name}`,
        ], exec_opt, {docker_volume});
    }
    else
    {
        await exec('convert', [
            `${dir}/${src_name}`,
            ...params,  
            `${dir}/${dst_name}`,
        ], {cwd: dir, ...exec_opt});
    }
};

const processImage = async (src, items, opt) =>{
    const {dir, exec_opt} = opt;
    const entries = items.reduce((r, item)=>{
        if (typeof item == 'string')
            item = {size: item};
        let {size, filename} = item;
        item.filename = filename || size.toUpperCase()+'.png';
        const fname = `${dir}/${item.filename}`;
        if (!fs.existsSync(fname))
            r.push(item);
        return r;
    }, []);
    if (!entries.length)
        return;
    for (const entry of entries)
    {
        const {size, scale, transform = 'resize', filename: dst} = entry;
        switch (transform)
        {
        case 'resize':
            await resizeImage(src, dst, dir, {
                docker: opt.docker,
                gravity: entry.gravity || opt.image_gravity,
                size, scale, exec_opt,
            });
            break;
        case 'round':
            await roundImage(src, dst, dir, {
                docker: opt.docker,
                exec_opt,
            });
            break;
        default: throw new Error(`unknown transform: ${transform}`);
        }
        if (entry.compress || opt.compress_images)
        {
            await compressImage(path.join(dir, dst), {
                docker: opt.docker,
                exec_opt,
            });
        }
    }
};

const dockerSplitFilename = dst=>({
    volume: path.dirname(dst),
    filename: path.basename(dst),
});

const compressImage = async(fname, opt={})=>{
    const {docker, exec_opt} = opt;
    if (docker)
    {
        const {volume, filename} = dockerSplitFilename(fname);
        await docker_exec('brightvideo/pngcrush', volume, [
            'pngcrush', '-rem', 'alla', '-brute', '-ow', filename,
        ], exec_opt, {docker_volume: '/source'});
    }
    else
        await exec('pngcrush', ['-brute', '-ow', fname], exec_opt);
};

const roundImage = async(src, dst, dir, opt)=>{
    const {docker, exec_opt} = opt;
    if (docker)
    {
        await exec('bash', [
            `${__dirname}/scripts/docker_round_image.sh`,
            dir, src, dst,
        ], exec_opt);
    }
    else
    {
        await exec('bash', [
            `${__dirname}/scripts/round_image.sh`,
            `${dir}/${src}`, `${dir}/${dst}`,
        ], {cwd: dir, ...exec_opt});
    }
};

const logFactory = new LogFactory(['images']);
const debug = {
    main: logFactory.create_debug_logger('images'),
};

/** images:
[
    {name: 'image1', filename: 'image1.png', items: [
        {size: '128x128'}, // resize
        {size: '256x256', filename: 'image1_256.png'}, // resize and rename
        {transform: 'round'}, // round image
    ]},
    ...
]
*/

const processImages = async (images, opt={})=>{
    for (const image of images)
    {
        const exists = fs.existsSync(path.join(opt.dir, image.filename));
        if (!exists && !opt.skip_missing)
            throw new Error(`image not found: ${image.filename}`);
        debug.main('%s: %s (%s) [%d items]',
            exists ? 'found' : 'skipping',
            image.name, image.filename,
            image.items ? image.items.length : 0
        );
        if (exists)
            await processImage(image.filename, image.items, opt);
    }
};

module.exports = processImages;