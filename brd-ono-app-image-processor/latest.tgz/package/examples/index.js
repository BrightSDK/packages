const yaml = require('yaml');
const fs = require('fs');
const processImages = require('../index.js');
const { Exec } = require('brd-ono-util-exec');

(async()=>{
    const { exec, cleanup } = Exec();
    const text = fs.readFileSync('./config.yml', 'utf8');
    const {assets} = yaml.parse(text);
    const dir_1 = './app_1';
    await exec('mkdir', ['-p', dir_1]);
    await exec('cp', ['images/poster.png', dir_1]);
    await processImages(assets, { dir: dir_1, docker: true, compress_images: false });
    const dir_2 = './app_2';
    await exec('mkdir', ['-p', dir_2]);
    await exec('cp', ['images/poster.png', dir_2]);
    await exec('cp', ['images/icon.png', dir_2]);
    await processImages(assets, { dir: dir_2, docker: true, compress_images: false });
    await exec('rm', ['-rf', 'app_*'], {options: {shell: true}});
    cleanup();
})();
