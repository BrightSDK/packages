#!/usr/bin/env bash
# LICENSE_CODE ZON

docker run -v "$1:/imgs" dpokidov/imagemagick:7.1.1-20 /imgs/$2 \
	-resize 800x800 \
	-background none \
	-gravity Center \
	-extent 800x800 \
	"/imgs/$3"

docker run -v "$1:/imgs" dpokidov/imagemagick:7.1.1-20 /imgs/$3 \
	-gravity Center \
	\( -size 800x800 \
	   xc:Black \
	   -fill White \
	   -draw 'circle 400 400 400 1' \
	   -alpha Copy \
	\) -compose CopyOpacity -composite -trim \
	"/imgs/$3"
