#!/usr/bin/env bash
# LICENSE_CODE ZON

convert "$1" \
	-resize 800x800 \
	-background none \
	-gravity Center \
	-extent 800x800 \
	"$2"

convert "$2" \
	-gravity Center \
	\( -size 800x800 \
	   xc:Black \
	   -fill White \
	   -draw 'circle 400 400 400 1' \
	   -alpha Copy \
	\) -compose CopyOpacity -composite -trim \
	"$2"
